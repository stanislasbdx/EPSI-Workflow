# Examen Javascript et Framework JS

## Sujet

👨‍🏫 Formateur: Ladrat Geoffroy

🔗 Lien: <https://gl-conseil.dev/examen_js_24/>

---

## Repo

<https://github.com/stanislasbdx/EPSI-Workflow/tree/master/Javascript/ControleJS%26Angular>